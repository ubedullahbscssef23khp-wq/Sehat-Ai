import type { ClinicianSummary, Language } from "../api/types";
import { strings } from "../i18n/strings";
import { AlertIcon, PulseIcon, ShieldIcon } from "./Icons";

interface ClinicianSummaryViewProps {
  summary: ClinicianSummary;
  language: Language;
}

export function ClinicianSummaryView({ summary, language }: ClinicianSummaryViewProps) {
  const t = strings(language);
  const { structured_case, fired_rules, triage_decision, timeline } = summary;

  const hasSymptoms = structured_case.symptoms && structured_case.symptoms.length > 0;
  const hasAge = Boolean(
    structured_case.demographics?.age_group && structured_case.demographics.age_group !== "unknown",
  );
  const hasPregnancy =
    structured_case.demographics?.pregnant !== null &&
    structured_case.demographics?.pregnant !== undefined;
  const hasDemographics = hasAge || hasPregnancy;
  const hasRedFlags =
    structured_case.red_flag_signals && structured_case.red_flag_signals.length > 0;
  const hasFiredRules = fired_rules && fired_rules.length > 0;
  const hasTimeline = timeline && timeline.length > 0;

  return (
    <details className="clinician-summary">
      <summary className="clinician-summary__summary">
        <span className="clinician-summary__icon" aria-hidden="true">
          <PulseIcon size={16} />
        </span>
        <span className="clinician-summary__title">{t.clinicianSummaryHeading}</span>
        <span className="clinician-summary__badge">{t.clinicianSummaryBadge}</span>
      </summary>

      <div className="clinician-summary__content">
        {structured_case.chief_complaint && (
          <div className="clinician-summary__section">
            <h4 className="clinician-summary__section-title">{t.chiefComplaintLabel}</h4>
            <p className="clinician-summary__text">{structured_case.chief_complaint}</p>
          </div>
        )}

        {triage_decision && (
          <div className="clinician-summary__section">
            <h4 className="clinician-summary__section-title">{t.triageDecisionLabel}</h4>
            <span
              className={`clinician-summary__triage-badge clinician-summary__triage-badge--${triage_decision.level}`}
            >
              {t.triageLabels[triage_decision.level]}
            </span>
          </div>
        )}

        {hasSymptoms && (
          <div className="clinician-summary__section">
            <h4 className="clinician-summary__section-title">{t.symptomsLabel}</h4>
            <ul className="clinician-summary__symptom-list">
              {structured_case.symptoms.map((symptom, idx) => (
                <li key={idx} className="clinician-summary__symptom-item">
                  <span className="clinician-summary__symptom-name">{symptom.name}</span>
                  <div className="clinician-summary__symptom-details">
                    {symptom.severity !== null && (
                      <span className="clinician-summary__tag">
                        {t.severityLabel}: {symptom.severity}/10
                      </span>
                    )}
                    {symptom.duration && (
                      <span className="clinician-summary__tag">
                        {t.durationLabel}: {symptom.duration}
                      </span>
                    )}
                    {symptom.progression && symptom.progression !== "unknown" && (
                      <span className="clinician-summary__tag">
                        {t.progressionLabel}: {symptom.progression}
                      </span>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        )}

        {hasDemographics && (
          <div className="clinician-summary__section">
            <h4 className="clinician-summary__section-title">{t.demographicsLabel}</h4>
            <div className="clinician-summary__tags">
              {hasAge && (
                <span className="clinician-summary__tag">
                  {t.ageGroupLabel}: {structured_case.demographics.age_group}
                </span>
              )}
              {hasPregnancy && (
                <span className="clinician-summary__tag">
                  {t.pregnancyLabel}:{" "}
                  {structured_case.demographics.pregnant ? t.pregnantYes : t.pregnantNo}
                </span>
              )}
            </div>
          </div>
        )}

        {hasRedFlags && (
          <div className="clinician-summary__section clinician-summary__section--alert">
            <h4 className="clinician-summary__section-title">
              <AlertIcon size={14} />
              <span>{t.redFlagsLabel}</span>
            </h4>
            <ul className="clinician-summary__signal-list">
              {structured_case.red_flag_signals.map((signal, idx) => (
                <li key={idx} className="clinician-summary__signal-item">
                  {signal}
                </li>
              ))}
            </ul>
          </div>
        )}

        {hasFiredRules && (
          <div className="clinician-summary__section">
            <h4 className="clinician-summary__section-title">
              <ShieldIcon size={14} />
              <span>{t.firedRulesLabel}</span>
            </h4>
            <ul className="clinician-summary__rule-list">
              {fired_rules.map((rule, idx) => (
                <li key={idx} className="clinician-summary__rule-item">
                  <span className="clinician-summary__rule-desc">{rule.description}</span>
                  {rule.level && (
                    <span className="clinician-summary__rule-level">
                      {rule.level.toUpperCase()}
                    </span>
                  )}
                </li>
              ))}
            </ul>
          </div>
        )}

        {hasTimeline && (
          <div className="clinician-summary__section">
            <h4 className="clinician-summary__section-title">{t.timelineLabel}</h4>
            <ol className="clinician-summary__timeline-list">
              {timeline.map((entry, idx) => (
                <li key={idx} className="clinician-summary__timeline-item">
                  {entry}
                </li>
              ))}
            </ol>
          </div>
        )}
      </div>
    </details>
  );
}
