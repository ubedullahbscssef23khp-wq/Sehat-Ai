import type { GuidanceResponse, LocalizedText, TriageDecision, TriageLevel } from "../api/types";

/**
 * Synthetic, non-clinical test fixture generator.
 * Contains only synthetic placeholders to test UI rendering without medical claims.
 */

export function syntheticLocalized(
  en: string = "Synthetic English text",
  ur: string | null = null,
  sd: string | null = null
): LocalizedText {
  return { en, ur, sd };
}

export function syntheticTriageDecision(
  level: TriageLevel = "routine",
  overrides?: Partial<TriageDecision>
): TriageDecision {
  return {
    level,
    fired_rule_ids: ["SYNTHETIC_RULE_001"],
    next_actions: [syntheticLocalized("Synthetic next action")],
    self_care_limits: [syntheticLocalized("Synthetic self-care limit")],
    recheck_advice: syntheticLocalized("Synthetic recheck advice"),
    limited_confidence: false,
    ...overrides,
  };
}

export function syntheticGuidanceResponse(
  level: TriageLevel = "routine",
  overrides?: Partial<GuidanceResponse>
): GuidanceResponse {
  return {
    session_id: "synthetic-session-123",
    user_message: syntheticLocalized("Synthetic guidance user message"),
    triage: syntheticTriageDecision(level),
    follow_up_questions: [syntheticLocalized("Synthetic follow-up question")],
    evidence: [],
    evidence_note: null,
    disclaimers: [
      syntheticLocalized("Synthetic primary disclaimer"),
      syntheticLocalized("Synthetic secondary disclaimer"),
    ],
    clinician_summary: {
      structured_case: {
        chief_complaint: "Synthetic symptom",
        symptoms: [],
        demographics: {
          age_group: null,
          pregnant: null,
        },
        associated_factors: [],
        red_flag_signals: [],
        missing_fields: [],
        confidence: 1.0,
        raw_excerpt: "Synthetic excerpt",
      },
      fired_rules: [],
      triage_decision: syntheticTriageDecision(level),
      timeline: ["Synthetic timeline event"],
      generated_at: "2026-09-04T00:00:00Z",
      model_attribution: null,
    },
    ...overrides,
  };
}
