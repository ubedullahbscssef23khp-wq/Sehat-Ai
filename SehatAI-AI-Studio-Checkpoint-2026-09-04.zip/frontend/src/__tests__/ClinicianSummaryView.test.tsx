import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import type { ClinicianSummary } from "../api/types";
import { ClinicianSummaryView } from "../components/ClinicianSummaryView";
import { strings } from "../i18n/strings";
import { syntheticGuidanceResponse } from "./fixtures";

describe("ClinicianSummaryView", () => {
  const baseSummary = syntheticGuidanceResponse("routine").clinician_summary as ClinicianSummary;

  it("renders when supplied and displays the summary heading and badge", () => {
    const t = strings("en");
    render(<ClinicianSummaryView summary={baseSummary} language="en" />);

    expect(screen.getByText(t.clinicianSummaryHeading)).toBeInTheDocument();
    expect(screen.getByText(t.clinicianSummaryBadge)).toBeInTheDocument();
  });

  it("renders chief complaint when present", () => {
    const summary: ClinicianSummary = {
      ...baseSummary,
      structured_case: {
        ...baseSummary.structured_case,
        chief_complaint: "Synthetic headache",
      },
    };
    render(<ClinicianSummaryView summary={summary} language="en" />);

    expect(screen.getByText("Synthetic headache")).toBeInTheDocument();
  });

  it("renders symptoms with severity, duration, and progression tags", () => {
    const summary: ClinicianSummary = {
      ...baseSummary,
      structured_case: {
        ...baseSummary.structured_case,
        symptoms: [
          {
            name: "Synthetic fever",
            body_system: "general",
            severity: 7,
            progression: "worsening",
            duration: "3 days",
          },
        ],
      },
    };
    render(<ClinicianSummaryView summary={summary} language="en" />);

    expect(screen.getByText("Synthetic fever")).toBeInTheDocument();
    expect(screen.getByText(/7\/10/)).toBeInTheDocument();
    expect(screen.getByText(/3 days/)).toBeInTheDocument();
    expect(screen.getByText(/worsening/)).toBeInTheDocument();
  });

  it("renders demographics when age group and pregnancy status are present", () => {
    const summary: ClinicianSummary = {
      ...baseSummary,
      structured_case: {
        ...baseSummary.structured_case,
        demographics: {
          age_group: "adult",
          pregnant: true,
        },
      },
    };
    const t = strings("en");
    render(<ClinicianSummaryView summary={summary} language="en" />);

    expect(screen.getByText(`${t.ageGroupLabel}: adult`)).toBeInTheDocument();
    expect(screen.getByText(`${t.pregnancyLabel}: ${t.pregnantYes}`)).toBeInTheDocument();
  });

  it("renders red flag signals with alert section styling", () => {
    const summary: ClinicianSummary = {
      ...baseSummary,
      structured_case: {
        ...baseSummary.structured_case,
        red_flag_signals: ["Synthetic red flag warning"],
      },
    };
    const { container } = render(<ClinicianSummaryView summary={summary} language="en" />);

    expect(screen.getByText("Synthetic red flag warning")).toBeInTheDocument();
    expect(container.querySelector(".clinician-summary__section--alert")).not.toBeNull();
  });

  it("renders fired rules with description and level without exposing internal rule IDs", () => {
    const summary: ClinicianSummary = {
      ...baseSummary,
      fired_rules: [
        {
          rule_id: "INTERNAL_SECRET_RULE_999",
          level: "urgent_same_day",
          description: "Synthetic rule description for clinicians",
        },
      ],
    };
    render(<ClinicianSummaryView summary={summary} language="en" />);

    expect(screen.getByText("Synthetic rule description for clinicians")).toBeInTheDocument();
    expect(screen.getByText("URGENT_SAME_DAY")).toBeInTheDocument();
    // Internal rule ID is not rendered to user
    expect(screen.queryByText("INTERNAL_SECRET_RULE_999")).toBeNull();
  });

  it("renders timeline entries when present", () => {
    const summary: ClinicianSummary = {
      ...baseSummary,
      timeline: ["Day 1: Synthetic onset", "Day 2: Synthetic progression"],
    };
    render(<ClinicianSummaryView summary={summary} language="en" />);

    expect(screen.getByText("Day 1: Synthetic onset")).toBeInTheDocument();
    expect(screen.getByText("Day 2: Synthetic progression")).toBeInTheDocument();
  });

  it("omits empty or null optional fields gracefully", () => {
    const summary: ClinicianSummary = {
      ...baseSummary,
      structured_case: {
        ...baseSummary.structured_case,
        symptoms: [],
        red_flag_signals: [],
        demographics: { age_group: null, pregnant: null },
      },
      fired_rules: [],
      timeline: [],
    };
    const t = strings("en");
    render(<ClinicianSummaryView summary={summary} language="en" />);

    expect(screen.queryByText(t.symptomsLabel)).toBeNull();
    expect(screen.queryByText(t.demographicsLabel)).toBeNull();
    expect(screen.queryByText(t.redFlagsLabel)).toBeNull();
    expect(screen.queryByText(t.firedRulesLabel)).toBeNull();
    expect(screen.queryByText(t.timelineLabel)).toBeNull();
  });

  it("renders localized labels in Urdu", () => {
    const tUr = strings("ur");
    render(<ClinicianSummaryView summary={baseSummary} language="ur" />);

    expect(screen.getByText(tUr.clinicianSummaryHeading)).toBeInTheDocument();
    expect(screen.getByText(tUr.clinicianSummaryBadge)).toBeInTheDocument();
  });

  it("renders localized labels in Sindhi", () => {
    const tSd = strings("sd");
    render(<ClinicianSummaryView summary={baseSummary} language="sd" />);

    expect(screen.getByText(tSd.clinicianSummaryHeading)).toBeInTheDocument();
    expect(screen.getByText(tSd.clinicianSummaryBadge)).toBeInTheDocument();
  });

  it("uses HTML details/summary for collapsible state", () => {
    const { container } = render(<ClinicianSummaryView summary={baseSummary} language="en" />);
    const details = container.querySelector("details.clinician-summary");
    expect(details).toBeInTheDocument();
    expect(container.querySelector("summary.clinician-summary__summary")).toBeInTheDocument();
  });
});
