import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { beforeEach, describe, expect, it, vi } from "vitest";
import App from "../App";
import * as client from "../api/client";
import * as health from "../api/health";
import { strings } from "../i18n/strings";
import { syntheticGuidanceResponse, syntheticLocalized } from "./fixtures";

vi.mock("../api/health");
vi.mock("../api/client", async (importOriginal) => {
  const actual = await importOriginal<typeof import("../api/client")>();
  return {
    ...actual,
    createSession: vi.fn(),
    sendMessage: vi.fn(),
  };
});

describe("App UI State & Integration", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(health.fetchHealth).mockResolvedValue({
      status: "ok",
      service: "sehat-ai",
      env: "test",
      llm_provider: "mock",
    });
  });

  it("renders initial landing state with Hero and empty-state composer", async () => {
    const t = strings("en");
    render(<App />);

    expect(screen.getAllByText(t.appName).length).toBeGreaterThanOrEqual(1);
    expect(screen.getByRole("heading", { level: 1, name: t.heroTitle })).toBeInTheDocument();
    expect(screen.getByRole("textbox", { name: t.inputPlaceholder })).toBeInTheDocument();
  });

  it("renders assistant response after sending a message", async () => {
    const user = userEvent.setup();
    const mockSession = {
      id: "test-session-1",
      created_at: "2026-09-04T00:00:00Z",
      preferred_language: "en" as const,
      status: "collecting" as const,
    };
    const mockResponse = syntheticGuidanceResponse("routine", {
      user_message: syntheticLocalized("Synthetic clinical advice for user"),
    });

    vi.mocked(client.createSession).mockResolvedValueOnce(mockSession);
    vi.mocked(client.sendMessage).mockResolvedValueOnce(mockResponse);

    render(<App />);

    const input = screen.getByRole("textbox");
    await user.type(input, "Synthetic symptom report{Enter}");

    // Shows user message in chat
    expect(screen.getByText("Synthetic symptom report")).toBeInTheDocument();

    // Awaits assistant message response
    await waitFor(() => {
      expect(screen.getByText("Synthetic clinical advice for user")).toBeInTheDocument();
    });

    // Shows New Conversation button now that conversation is active
    expect(screen.getByRole("button", { name: strings("en").newConversation })).toBeInTheDocument();
  });

  it("renders error banner when API sendMessage fails", async () => {
    const user = userEvent.setup();
    const mockSession = {
      id: "test-session-err",
      created_at: "2026-09-04T00:00:00Z",
      preferred_language: "en" as const,
      status: "collecting" as const,
    };

    vi.mocked(client.createSession).mockResolvedValueOnce(mockSession);
    vi.mocked(client.sendMessage).mockRejectedValueOnce(
      new client.ApiError(503, "llm_unavailable", "Service unavailable")
    );

    render(<App />);

    const input = screen.getByRole("textbox");
    await user.type(input, "Fever symptom{Enter}");

    await waitFor(() => {
      expect(screen.getByRole("alert")).toBeInTheDocument();
      expect(screen.getByText(strings("en").errorUnavailable)).toBeInTheDocument();
    });
  });

  it("resets conversation to landing state when New Conversation is clicked", async () => {
    const user = userEvent.setup();
    const mockSession = {
      id: "test-session-reset",
      created_at: "2026-09-04T00:00:00Z",
      preferred_language: "en" as const,
      status: "collecting" as const,
    };
    const mockResponse = syntheticGuidanceResponse("routine", {
      user_message: syntheticLocalized("Synthetic advice"),
    });

    vi.mocked(client.createSession).mockResolvedValueOnce(mockSession);
    vi.mocked(client.sendMessage).mockResolvedValueOnce(mockResponse);

    render(<App />);

    const input = screen.getByRole("textbox");
    await user.type(input, "Initial message{Enter}");

    await waitFor(() => {
      expect(screen.getByText("Synthetic advice")).toBeInTheDocument();
    });

    const newConversationBtn = screen.getByRole("button", {
      name: strings("en").newConversation,
    });
    await user.click(newConversationBtn);

    // Returns to Hero state
    expect(screen.getByRole("heading", { level: 1, name: strings("en").heroTitle })).toBeInTheDocument();
    expect(screen.queryByText("Synthetic advice")).toBeNull();
  });
});
